package com.hospital.appointmentservice.receptionist.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.*;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;

@Configuration
public class AppSecurityBeans {

    @Bean
    public AuthenticationProvider authenticationProvider(CustomUserDetailsService userDetailsService) {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        //TRUY VAN USER VA SO SANH MAT KHAU TU DATABASE
        provider.setUserDetailsService(userDetailsService);
        provider.setPasswordEncoder(userDetailsService.passwordEncoder());
        return provider;
    }
}
