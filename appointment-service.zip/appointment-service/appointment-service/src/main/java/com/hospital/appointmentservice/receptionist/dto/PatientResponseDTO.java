package com.hospital.appointmentservice.receptionist.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PatientResponseDTO {
    private Integer id;
    private String name;
    private String email;
    private String phone;
    private String dob;
    private String gender;
    private String address;
}

