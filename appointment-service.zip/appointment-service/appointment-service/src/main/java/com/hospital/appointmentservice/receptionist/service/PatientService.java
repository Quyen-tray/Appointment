package com.hospital.appointmentservice.receptionist.service;

import com.hospital.appointmentservice.receptionist.dto.PatientResponseDTO;
import com.hospital.appointmentservice.receptionist.dto.PatientDetailDTO;
import com.hospital.appointmentservice.receptionist.dto.PatientHistoryDTO;
import com.hospital.appointmentservice.receptionist.entity.Appointment;
import com.hospital.appointmentservice.receptionist.entity.MedicalRecord;
import com.hospital.appointmentservice.receptionist.entity.Patient;
import com.hospital.appointmentservice.receptionist.entity.User;
import com.hospital.appointmentservice.receptionist.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    public List<PatientResponseDTO> getAllPatients() {
        List<Patient> patients = patientRepository.findAll();
        List<PatientResponseDTO> dtos = new ArrayList<>();

        for (Patient p : patients) {
            User u = p.getUser();
            dtos.add(new PatientResponseDTO(
                    p.getId(),
                    u.getFullName(),
                    u.getEmail(),
                    u.getPhone(),
                    p.getDob(),
                    p.getGender(),
                    p.getAddress()
            ));
        }

        return dtos;
    }


    public PatientDetailDTO getPatientWithHistory(Integer id) {
        Patient patient = patientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Patient not found"));

        User user = patient.getUser();

        List<PatientHistoryDTO> history = new ArrayList<>();
        List<Appointment> appointments = patient.getAppointments();

        if (appointments != null) {
            for (Appointment a : appointments) {
                MedicalRecord mr = a.getMedicalRecord();
                history.add(new PatientHistoryDTO(
                        a.getAppointmentDate().toString(),
                        a.getReason(),
                        a.getStatus(),
                        mr != null ? mr.getDiagnosis() : null,
                        mr != null ? mr.getNotes() : null,
                        mr != null ? mr.getCreatedAt().toString() : null
                ));
            }
        }

        return new PatientDetailDTO(
                patient.getId().longValue(),
                user.getFullName(),
                user.getEmail(),
                user.getPhone(),
                patient.getDob(),
                patient.getGender(),
                patient.getAddress(),
                history
        );
    }


    public PatientResponseDTO getPatientById(Integer id) {
        Patient patient = patientRepository.findById(id).orElse(null);
        if (patient != null) {
            User u = patient.getUser();
            return new PatientResponseDTO(
                    patient.getId(),
                    u.getFullName(),
                    u.getEmail(),
                    u.getPhone(),
                    patient.getDob(),
                    patient.getGender(),
                    patient.getAddress()
            );
        }
        return null;
    }
}

