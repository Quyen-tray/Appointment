package com.hospital.appointmentservice.receptionist.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "MedicalRecords")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class MedicalRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(columnDefinition = "NVARCHAR(MAX)")
    private String diagnosis;

    @Column(columnDefinition = "NVARCHAR(MAX)")
    private String notes;

    private LocalDateTime createdAt = LocalDateTime.now();


    @OneToOne
    @JoinColumn(name = "appointmentId", nullable = false, unique = true)
    private Appointment appointment;
}

