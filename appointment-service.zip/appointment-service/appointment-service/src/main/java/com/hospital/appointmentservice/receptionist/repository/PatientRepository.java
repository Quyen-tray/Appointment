package com.hospital.appointmentservice.receptionist.repository;

import com.hospital.appointmentservice.receptionist.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PatientRepository extends JpaRepository<Patient, Integer> {
}
