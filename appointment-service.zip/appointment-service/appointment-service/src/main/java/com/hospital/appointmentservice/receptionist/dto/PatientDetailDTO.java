package com.hospital.appointmentservice.receptionist.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PatientDetailDTO {
    private Long id;
    private String name;
    private String email;
    private String phone;
    private String dob;
    private String gender;
    private String address;
    private List<PatientHistoryDTO> history;
}
