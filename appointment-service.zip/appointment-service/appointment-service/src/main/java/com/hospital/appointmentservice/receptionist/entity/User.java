package com.hospital.appointmentservice.receptionist.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "Users")
@Data
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;

    private String password;

    private String email;

    private String fullName;

    private String phone;

    @ManyToOne
    @JoinColumn(name = "roleId")
    private Role role;
}

