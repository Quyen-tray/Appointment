package com.hospital.appointmentservice.receptionist.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "Appointments")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private LocalDateTime appointmentDate;

    @Column(columnDefinition = "NVARCHAR(MAX)")
    private String reason;

    private String status;


    @ManyToOne
    @JoinColumn(name = "patientId", nullable = false)
    private Patient patient;


    @ManyToOne
    @JoinColumn(name = "doctorId", nullable = false)
    private Doctor doctor;


    @OneToOne(mappedBy = "appointment", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private MedicalRecord medicalRecord;
}
