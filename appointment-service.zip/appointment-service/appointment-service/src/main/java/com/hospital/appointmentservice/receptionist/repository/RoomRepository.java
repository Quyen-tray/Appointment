package com.hospital.appointmentservice.receptionist.repository;

import com.hospital.appointmentservice.receptionist.entity.Room;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoomRepository extends JpaRepository<Room, Integer> {
}
