package com.hospital.appointmentservice.auth.security;

public class JwtFilter {
}
