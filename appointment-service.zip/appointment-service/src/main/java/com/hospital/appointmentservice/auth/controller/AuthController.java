package com.hospital.appointmentservice.auth.controller;

import com.hospital.appointmentservice.auth.dto.UserAccountDto;
import com.hospital.appointmentservice.auth.service.AuthService;
import com.hospital.appointmentservice.patient.dto.PatientDto;
import com.hospital.appointmentservice.patient.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService authService;
    private final PatientService patientService;

    @Autowired
    public AuthController(AuthService authService, PatientService patientService) {
        this.authService = authService;
        this.patientService = patientService;
    }

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody UserAccountDto userAccountDto) {
        try {
            //valid name existed in database table user account
            if(authService.existsByUserName(userAccountDto.getUsername())){
                return  ResponseEntity.status(HttpStatus.CONFLICT).body("Username is already taken");
            }
            //valid email existed in database in table patient
            if(patientService.existsPatientByEmail(userAccountDto.getEmail())){
                return  ResponseEntity.status(HttpStatus.CONFLICT).body("Email is already taken");
            }
            //save user account in database
            authService.registerUser(userAccountDto);

            //Create 1 record patient in patient table
            PatientDto patientDto = new PatientDto();
            patientDto.setFullName(userAccountDto.getUsername());
            patientDto.setEmail(userAccountDto.getEmail());
            patientService.addPatient(patientDto);

            return ResponseEntity.status(HttpStatus.CREATED).body("User registered successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Errors in register process"+e.getMessage());
        }

    }

}
