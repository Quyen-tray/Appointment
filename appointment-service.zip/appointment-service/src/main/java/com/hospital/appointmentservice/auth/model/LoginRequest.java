package com.hospital.appointmentservice.auth.model;

public class LoginRequest {
}
